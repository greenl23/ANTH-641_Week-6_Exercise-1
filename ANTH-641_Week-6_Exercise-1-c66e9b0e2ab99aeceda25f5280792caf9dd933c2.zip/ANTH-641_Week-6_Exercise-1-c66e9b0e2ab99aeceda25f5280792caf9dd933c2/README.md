# Readme

https://mybinder.org/v2/gh/greenl23/ANTH-641_Week-6_Exercise-1/master

This repo holds a few different tools for extracting data. Some are taken from the o-date/scraping GitHub repo. Make sure to fork this repo and set up your own binder to work with the notebooks. 

Check out the __Week-6_1__ file in this repo for the instructions. 

default-jre in apt.txt gives me java 10, but some of what I'm reading suggests java 8. Trying this: https://tecadmin.net/install-oracle-java-8-ubuntu-via-ppa/

first made a new jupyter binder
