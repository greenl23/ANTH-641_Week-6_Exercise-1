This folder holds the images for the Exercise instructions.
